import java.util.*;
import java.net.*;
import java.io.*;


public class url
{ public String finalCityName;
    public String l3,l7,l10;
    public  int lang;
    public int urlcall(String finalCityName,int lang) throws Exception
    {   lang+=1;
        //Scanner input = new Scanner(System.in);
//SELECTING LANGUAGE

//IF LANGUAGE OF CHOICE IS ENGLISH

        if (lang == 1)
        {

//INPUTTING CITY NAME



//STRING MANIPULATION


//CREATING URL

            String urlString = "http://WWW.weather-forecast.com/locations/"+finalCityName+"/forecasts/latest";
            //System.out.println(urlString);
            URL myurl = new URL(urlString);
            try
            {
                URLConnection myUrlConnection = myurl.openConnection();
                myUrlConnection.connect();
            }
            catch(MalformedURLException e)
            {
                return -1;
            }
            catch(IOException e)
            {
                return -1;
            }
//PARSING THE URL

            BufferedReader in = new BufferedReader(new InputStreamReader(myurl.openStream()));
            String webContent = "";
            while (in.readLine() != null)
            {
                webContent += in.readLine();

            }
            in.close();


//3 DAYS
            String[] tokens = webContent.split("</b><span class=\"read-more-small\"><span class=\"read-more-content\"> <span class=\"phrase\">");
            String token1 = tokens[1];
            String[] newTokens = token1.split("</span></span>");
            newTokens[0].replaceAll("&deg;", "");
            l3=newTokens[0];

//7 DAYS
            String token2 = tokens[2];
            String[] newTokens1 = token2.split("</span></span>");
            newTokens1[0].replaceAll("&deg;", "");
            l7=newTokens1[0];
            //10 DAYS
            String token3 = tokens[3];
            String[] newTokens2 = token3.split("</span></span>");
            newTokens2[0].replaceAll("&deg;", "");
            l10=newTokens2[0];
        }

//IF LANGUAGE OF CHOICE IS FRENCH

        else if (lang == 2)
        {

            String urlString = "http://fr.weather-forecast.com/locations/"+finalCityName+"/forecasts/latest";
            //System.out.println(urlString);
            URL myurl = new URL(urlString);
            try
            {
                URLConnection myUrlConnection = myurl.openConnection();
                myUrlConnection.connect();
            }
            catch(MalformedURLException e)
            {
                return -1;
            }
            catch(IOException e)
            {
                return -1;
            }
//PARSING THE URL

            BufferedReader in = new BufferedReader(new InputStreamReader(myurl.openStream()));
            String webContent = "";
            while (in.readLine() != null)
            {
                webContent += in.readLine();
            }
            in.close();
//3 DAYS
            String[] tokens = webContent.split("</b><span class=\"read-more-small\"><span class=\"read-more-content\"> <span class=\"phrase\">");
            String token1 = tokens[1];
            String[] newTokens = token1.split("</span></span>");
            newTokens[0].replaceAll("&deg;", "");
            l3=newTokens[0];
//7 DAYS
            String token2 = tokens[2];
            String[] newTokens1 = token2.split("</span></span>");
            newTokens1[0].replaceAll("&deg;", "");
            l7=newTokens1[0];
//10 DAYS
            String token3 = tokens[3];
            String[] newTokens2 = token3.split("</span></span>");
            newTokens2[0].replaceAll("&deg;", "");
            l10=newTokens2[0];
        }

//IF LANGUAGE OF CHOICE IS JAPANESE

        if (lang ==  3)
        {
            String urlString = "http://ja.weather-forecast.com/locations/"+finalCityName+"/forecasts/latest";
            //System.out.println(urlString);
            URL myurl = new URL(urlString);
            try
            {
                URLConnection myUrlConnection = myurl.openConnection();
                myUrlConnection.connect();
            }
            catch(MalformedURLException e)
            {
                return -1;
            }
            catch(IOException e)
            {
                return -1;
            }
            BufferedReader in = new BufferedReader(new InputStreamReader(myurl.openStream()));
            String webContent = "";
            while (in.readLine() != null)
            {
                webContent += in.readLine();
            }
            in.close();
//3 DAYS
            String[] tokens = webContent.split("</b><span class=\"read-more-small\"><span class=\"read-more-content\"> <span class=\"phrase\">");
            String token1 = tokens[1];
            String[] newTokens = token1.split("</span></span>");
            newTokens[0].replaceAll("&deg;", "");
            l3=newTokens[0];
//7 DAYS
            String token2 = tokens[2];
            String[] newTokens1 = token2.split("</span></span>");
            newTokens1[0].replaceAll("&deg;", "");
            l7=newTokens1[0];
//10 DAYS
            String token3 = tokens[3];
            String[] newTokens2 = token3.split("</span></span>");
            newTokens2[0].replaceAll("&deg;", "");
            l10=newTokens2[0];
        }

//IF LANGUAGE OF CHOICE IS SPANISH

         if (lang ==  4)
        {
            String urlString = "http://es.weather-forecast.com/locations/"+finalCityName+"/forecasts/latest";
            //System.out.println(urlString);
            URL myurl = new URL(urlString);
            try
            {
                URLConnection myUrlConnection = myurl.openConnection();
                myUrlConnection.connect();
            }
            catch(MalformedURLException e)
            {
                return -1;
            }
            catch(IOException e)
            {
                return -1;
            }
//PARSING THE URL

            BufferedReader in = new BufferedReader(new InputStreamReader(myurl.openStream()));
            String webContent = "";
            while (in.readLine() != null)
            {
                webContent += in.readLine();
            }
            in.close();

//3 DAYS

            String[] tokens = webContent.split("</b><span class=\"read-more-small\"><span class=\"read-more-content\"> <span class=\"phrase\">");
            String token1 = tokens[1];
            String[] newTokens = token1.split("</span></span>");
            newTokens[0].replaceAll("&deg;", "");
            l3=newTokens[0];
//7 DAYS

            String token2 = tokens[2];
            String[] newTokens1 = token2.split("</span></span>");
            newTokens1[0].replaceAll("&deg;", "");
            l7=newTokens1[0];
//10 DAYS


            String token3 = tokens[3];
            String[] newTokens2 = token3.split("</span></span>");
            newTokens2[0].replaceAll("&deg;", "");
            l10=newTokens2[0];
        }

//IF LANGUAGE OF CHOICE IS Nederlands

        else if (lang ==  5)
        {
            String urlString = "http://nl.weather-forecast.com/locations/"+finalCityName+"/forecasts/latest";
            //System.out.println(urlString);
            URL myurl = new URL(urlString);
            try
            {
                URLConnection myUrlConnection = myurl.openConnection();
                myUrlConnection.connect();
            }
            catch(MalformedURLException e)
            {
                return -1;
            }
            catch(IOException e)
            {
                return -1;
            }
//PARSING THE URL

            BufferedReader in = new BufferedReader(new InputStreamReader(myurl.openStream()));
            String webContent = "";
            while (in.readLine() != null)
            {
                webContent += in.readLine();
            }
            in.close();

//3 DAYS

            String[] tokens = webContent.split("</b><span class=\"read-more-small\"><span class=\"read-more-content\"> <span class=\"phrase\">");
            String token1 = tokens[1];
            String[] newTokens = token1.split("</span></span>");
            newTokens[0].replaceAll("&deg;", "");
            l3=newTokens[0];
//7 DAYS
            String token2 = tokens[2];
            String[] newTokens1 = token2.split("</span></span>");
            newTokens1[0].replaceAll("&deg;", "");
            l7=newTokens1[0];
//10 DAYS
            String token3 = tokens[3];
            String[] newTokens2 = token3.split("</span></span>");
            newTokens2[0].replaceAll("&deg;", "");
            l10=newTokens2[0];
        }

//IF LANGUAGE OF CHOICE IS CHINIZE

        if (lang ==  6)
        {
            String urlString = "http://zh.weather-forecast.com/locations/"+finalCityName+"/forecasts/latest";
            //System.out.println(urlString);
            URL myurl = new URL(urlString);
            try
            {
                URLConnection myUrlConnection = myurl.openConnection();
                myUrlConnection.connect();
            }
            catch(MalformedURLException e)
            {
                return -1;
            }
            catch(IOException e)
            {
                return -1;
            }
//PARSING THE URL

            BufferedReader in = new BufferedReader(new InputStreamReader(myurl.openStream()));
            String webContent = "";
            while (in.readLine() != null)
            {
                webContent += in.readLine();
            }
            in.close();
//3 DAYS
            String[] tokens = webContent.split("</b><span class=\"read-more-small\"><span class=\"read-more-content\"> <span class=\"phrase\">");
            String token1 = tokens[1];
            String[] newTokens = token1.split("</span></span>");
            newTokens[0].replaceAll("&deg;", "");
            l3=newTokens[0];
//7 DAYS
            String token2 = tokens[2];
            String[] newTokens1 = token2.split("</span></span>");
            newTokens1[0].replaceAll("&deg;", "");
            l7=newTokens1[0];
//10 DAYS
            String token3 = tokens[3];
            String[] newTokens2 = token3.split("</span></span>");
            newTokens2[0].replaceAll("&deg;", "");
            l10=newTokens2[0];
        }
        return 0;
    }
}