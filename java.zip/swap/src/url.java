import java.util.*;
import java.net.*;
import java.io.*;


public class url
{
    public static void main(String args[]) throws Exception
    {
        Scanner input = new Scanner(System.in);
//SELECTING LANGUAGE
        System.out.println("Enter your language of choice: \n1:English\n2:Français\n3:日本語\n4:Español\n5:Nederlands\n6:中文\n");
        Integer lang = Integer.parseInt(input.nextLine());

//IF LANGUAGE OF CHOICE IS ENGLISH

        if (lang == 1)
        {

//INPUTTING CITY NAME

            System.out.println("Entrer une ville (E.g. London, San Francisco etc...)");
            String cityName;
//STRING MANIPULATION

            cityName = input.nextLine();
            String trimmedNewCity = cityName.trim();
            String finalCityName = trimmedNewCity.replaceAll(" ","-");
            String fcn = finalCityName.substring(0, 1).toUpperCase() + finalCityName.substring(1);
            System.out.println(fcn);

//CREATING URL

            String urlString = "http://WWW.weather-forecast.com/locations/"+finalCityName+"/forecasts/latest";
            System.out.println(urlString);
            URL myurl = new URL(urlString);
            try
            {
                URLConnection myUrlConnection = myurl.openConnection();
                myUrlConnection.connect();
            }
            catch(MalformedURLException e)
            {
// System.out.println
            }
            catch(IOException e)
            {

            }
//PARSING THE URL

            BufferedReader in = new BufferedReader(new InputStreamReader(myurl.openStream()));
            String webContent = "";
            while (in.readLine() != null)
            {
                webContent += in.readLine();
// System.out.println(in.readLine());
            }
            in.close();
// System.out.println(webContent);

//3 DAYS

            System.out.println("FOR 3 DAYS");
            String[] tokens = webContent.split("</b><span class=\"read-more-small\"><span class=\"read-more-content\"> <span class=\"phrase\">");
            String token1 = tokens[1];
            String[] newTokens = token1.split("</span></span>");
            newTokens[0].replaceAll("&deg;", "");
            System.out.println(newTokens[0]);

//7 DAYS

            System.out.println("FOR 7 DAYS");
            String token2 = tokens[2];
            String[] newTokens1 = token2.split("</span></span>");
            newTokens1[0].replaceAll("&deg;", "");
            System.out.println(newTokens1[0]);

//10 DAYS

            System.out.println("FOR 10 DAYS");
            String token3 = tokens[3];
            String[] newTokens2 = token3.split("</span></span>");
            newTokens2[0].replaceAll("&deg;", "");
            System.out.println(newTokens2[0]);
        }

//IF LANGUAGE OF CHOICE IS FRENCH

        else if (lang == 2)
        {
            System.out.println("Enter a City (E.g. London, San Francisco etc...)");
            String cityName;
//STRING MANIPULATION

            cityName = input.nextLine();
            String trimmedNewCity = cityName.trim();
            String finalCityName = trimmedNewCity.replaceAll(" ","-");
            String fcn = finalCityName.substring(0, 1).toUpperCase() + finalCityName.substring(1);
            System.out.println(fcn);

//CREATING URL

            String urlString = "http://fr.weather-forecast.com/locations/"+finalCityName+"/forecasts/latest";
            System.out.println(urlString);
            URL myurl = new URL(urlString);
            try
            {
                URLConnection myUrlConnection = myurl.openConnection();
                myUrlConnection.connect();
            }
            catch(MalformedURLException e)
            {
// System.out.println
            }
            catch(IOException e)
            {

            }
//PARSING THE URL

            BufferedReader in = new BufferedReader(new InputStreamReader(myurl.openStream()));
            String webContent = "";
            while (in.readLine() != null)
            {
                webContent += in.readLine();
// System.out.println(in.readLine());
            }
            in.close();
// System.out.println(webContent);

//3 DAYS

            System.out.println("Pour 3 jours");
            String[] tokens = webContent.split("</b><span class=\"read-more-small\"><span class=\"read-more-content\"> <span class=\"phrase\">");
            String token1 = tokens[1];
            String[] newTokens = token1.split("</span></span>");
            newTokens[0].replaceAll("&deg;", "");
            System.out.println(newTokens[0]);

//7 DAYS

            System.out.println("Pour 7 jours");
            String token2 = tokens[2];
            String[] newTokens1 = token2.split("</span></span>");
            newTokens1[0].replaceAll("&deg;", "");
            System.out.println(newTokens1[0]);

//10 DAYS

            System.out.println("Pour 10 jours");
            String token3 = tokens[3];
            String[] newTokens2 = token3.split("</span></span>");
            newTokens2[0].replaceAll("&deg;", "");
            System.out.println(newTokens2[0]);
        }

//IF LANGUAGE OF CHOICE IS JAPANESE

        if (lang ==  3)
        {
            System.out.println("都市（例えば、ロンドン、サンフランシスコなど...）を入力します");
            String cityName;
//STRING MANIPULATION

            cityName = input.nextLine();
            String trimmedNewCity = cityName.trim();
            String finalCityName = trimmedNewCity.replaceAll(" ","-");
            String fcn = finalCityName.substring(0, 1).toUpperCase() + finalCityName.substring(1);
            System.out.println(fcn);

//CREATING URL

            String urlString = "http://jp.weather-forecast.com/locations/"+finalCityName+"/forecasts/latest";
            System.out.println(urlString);
            URL myurl = new URL(urlString);
            try
            {
                URLConnection myUrlConnection = myurl.openConnection();
                myUrlConnection.connect();
            }
            catch(MalformedURLException e)
            {
// System.out.println
            }
            catch(IOException e)
            {

            }
//PARSING THE URL

            BufferedReader in = new BufferedReader(new InputStreamReader(myurl.openStream()));
            String webContent = "";
            while (in.readLine() != null)
            {
                webContent += in.readLine();
// System.out.println(in.readLine());
            }
            in.close();
// System.out.println(webContent);

//3 DAYS

            System.out.println("3日間");
            String[] tokens = webContent.split("</b><span class=\"read-more-small\"><span class=\"read-more-content\"> <span class=\"phrase\">");
            String token1 = tokens[1];
            String[] newTokens = token1.split("</span></span>");
            newTokens[0].replaceAll("&deg;", "");
            System.out.println(newTokens[0]);

//7 DAYS

            System.out.println("7日間");
            String token2 = tokens[2];
            String[] newTokens1 = token2.split("</span></span>");
            newTokens1[0].replaceAll("&deg;", "");
            System.out.println(newTokens1[0]);

//10 DAYS

            System.out.println("10日間");
            String token3 = tokens[3];
            String[] newTokens2 = token3.split("</span></span>");
            newTokens2[0].replaceAll("&deg;", "");
            System.out.println(newTokens2[0]);
        }

//IF LANGUAGE OF CHOICE IS 
    }

}